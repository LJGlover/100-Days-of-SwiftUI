import UIKit

var greeting = "Hello, playground"

let celineSongs = ["Think Twice", "Misled", "Destin", "All By Myself", "Misled"]
let uniqueSongs = Array(Set(celineSongs))
print(celineSongs.count)
print(uniqueSongs)

