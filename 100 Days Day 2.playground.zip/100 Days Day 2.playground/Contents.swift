import UIKit

var greeting = "Hello, playground"

let celsius = Double(27.0)
let conversion = (celsius) * 9 / 5 + 32
let fahrenheit = "\(celsius) is \(conversion) F"
print(fahrenheit)
